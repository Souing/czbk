﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FluentAPI1
{
    public class Dog
    {
        public long Id { get; set; }
        public string Name { get; set; }
    }
}
