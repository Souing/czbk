﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FluentAPI1
{
    class GroupCount
    {
        public int Age { get; set; }
        public int AgeCount { get; set; }
    }
}
