﻿using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NPOITest
{
    class Program
    {
        static void Main(string[] args)
        {
            IWorkbook wb = new XSSFWorkbook();
            ISheet sheet =  wb.CreateSheet();
            IRow row = sheet.CreateRow(0);
            ICell cell0 = row.CreateCell(0);
            cell0.SetCellValue("如鹏");
            ICell cell1 = row.CreateCell(1);
            cell1.SetCellValue(3.14);
            ICell cell2 = row.CreateCell(2);
            //cell2.SetCellValue(DateTime.Now);
            //cell2.SetCellValue(DateTime.Now.ToShortDateString());
            cell2.SetCellValue(false);

            using (Stream stream
                = File.OpenWrite(@"E:\如鹏.net课程\NET\三层架构2017\Day3\1.xlsx"))
            {
                wb.Write(stream);
            }

        }
        static void Main2(string[] args)
        {
            //HSSFWorkbook
            //IWorkbook wb1= WorkbookFactory.Create(@"E:\如鹏.net课程\NET\三层架构2017\Day3\Book2.xls");
           // HSSFWorkbook wb3 = new HSSFWorkbook(File.OpenRead(@"E:\如鹏.net课程\NET\三层架构2017\Day3\Book2.xls"));
           // XSSFWorkbook
            //XSSFWorkbook
            IWorkbook wb2 = WorkbookFactory.Create(@"E:\如鹏.net课程\NET\三层架构2017\Day3\Book2.xlsx");
           // Console.WriteLine(wb1.GetType());
            //Console.WriteLine(wb2.GetType());
            /*
            ISheet sheet = wb2.GetSheetAt(0);
            IRow row0 =  sheet.GetRow(0);
            ICell cell00 = row0.GetCell(0);
            Console.WriteLine(cell00.CellType+","+cell00.StringCellValue);*/
            ISheet sheet = wb2.GetSheetAt(0);
            for (int i = 1; i <= sheet.LastRowNum;i++ )//<=
            {
                IRow row = sheet.GetRow(i);
                ICell cell0 = row.GetCell(0);
                ICell cell1 = row.GetCell(1);
                ICell cell2 = row.GetCell(2);
                ICell cell3 = row.GetCell(3);
                string name = cell0.StringCellValue;
                int age = (int)cell1.NumericCellValue;
                string bd = cell2.ToString();
                /*
                if(cell2.CellType== CellType.Numeric)
                {
                    bd = cell2.DateCellValue.ToString();
                }
                else if(cell2.CellType== CellType.String)
                {
                    bd = cell2.StringCellValue;
                }
                else
                {
                    bd = "未知";
                }*/


                string phoneNum = cell3.ToString();
                /*
                if(cell3.CellType== CellType.Numeric)
                {
                    phoneNum = cell3.NumericCellValue.ToString();
                }
                else if(cell3.CellType==CellType.String)
                {
                    phoneNum = cell3.StringCellValue;
                }
                else
                {
                    phoneNum = "未知";
                }*/
                Console.WriteLine("姓名"+name+",年龄"+age+"，生日"+bd+"，手机号"+phoneNum);

            }
                Console.ReadKey();
        }
    }
}
