﻿using SanCeng.BLL;
using SanCeng.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using System.Windows.Forms;

namespace SanCeng.Winform2
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            /*
            string userName = txtUserName.Text;
            string password = txtPwd.Text;
            User u = new UserBLL().GetByUserName(userName);
            if(u==null)
            {
                MessageBox.Show("用户名不存在！");
            }
            else if(u.Password==password)
            //else if(u.Password.Equals(password,StringComparison.OrdinalIgnoreCase))
            {
                new LogBLL().Add(u.Id,u.UserName+"登录系统");
                this.Close();
            }
            else
            {
                MessageBox.Show("密码错误");
            }*/
            string userName = txtUserName.Text;
            string password = txtPwd.Text;
            if(string.IsNullOrEmpty(userName))
            {
                MessageBox.Show("用户名不能为空");
                return;
            }
            if (string.IsNullOrEmpty(password))
            {
                MessageBox.Show("密码不能为空");
                return;
            }
            LoginResult result = new UserBLL().Login(userName, password);
            if(result== LoginResult.OK)
            {
                this.Close();
            }
            else if(result== LoginResult.PasswordError)
            {
                this.labelPwdError.Visible = true;
                //MessageBox.Show("密码错误");
            }
            else if(result== LoginResult.UserNameNotFound)
            {
                MessageBox.Show("用户名不存在");
            }
            else
            {
                MessageBox.Show("未知的状态");
            }
        }

        private void F1()
        {
            using(SqlConnection conn = new SqlConnection("Server=.;database=SanCeng;uid=sa;pwd=msn@qq888"))
            using(SqlCommand cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = "insert into T_Users(UserName,Password,PhoneNum,IsDeleted) values('abc','123','111',0)";
                cmd.ExecuteNonQuery();
            }
            
        }

        private void F2()
        {
            using (SqlConnection conn = new SqlConnection("Server=.;database=SanCeng;uid=sa;pwd=msn@qq888"))
            using (SqlCommand cmd = conn.CreateCommand())
            {
                conn.Open();
                cmd.CommandText = "insert into T_Users(UserName,Password,PhoneNum,IsDeleted) values('xyz','123','111',0)";
                cmd.ExecuteNonQuery();
            }

        }

        private void F3()
        {
            using(TransactionScope tx = new TransactionScope())
            {
                F1();
                F2();
                tx.Complete();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //放到TransactionScope范围内的SQL操作的连接字符串必须一模一样
            //否则就会要求启动MSDTC，如果没有启动MSDTC就会报错:MSDTC 不可用。
            /*
            using(TransactionScope tx= new TransactionScope())
            {
                F1();
                F2();
                tx.Complete();
            }*/
            //F3();
            
            using(TransactionScope tx= new TransactionScope())
            {
                F3();
                UserBLL bll = new UserBLL();
                bll.Add("xyzaaaaaaaaaaaaaa", "123", "111", 11);
                tx.Complete();
            }
            //事务：原子性。
            //同一个连接中，SQLTransaction，conn.BeginTransaction()
            //tx.RollBack();
            /*
            using(TransactionScope tx = new TransactionScope())
            { 
                UserBLL bll = new UserBLL();
                bll.Add("abc", "123", "111", 11);
                bll.Add("xyzaaaaaaaaaaaaaa", "123", "111", 11);
                tx.Complete();
            }*/
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
           // MessageBox.Show(MD5("abc123"));
           using(FileStream fs = File.OpenRead(@"D:\soft\7z_16.4.0.0.exe"))
           {
               string md5 = MD5(fs);
               MessageBox.Show(md5);
           }
        }


        public static string MD5(string s)
        {
            System.Security.Cryptography.MD5CryptoServiceProvider provider
                = new System.Security.Cryptography.MD5CryptoServiceProvider();
            byte[] bytes = System.Text.Encoding.UTF8.GetBytes(s);
            StringBuilder builder = new StringBuilder();
            bytes = provider.ComputeHash(bytes);
            foreach (byte b in bytes)
                builder.Append(b.ToString("x2").ToLower());
            return builder.ToString();
        }

        public static string MD5(Stream stream)
        {
            System.Security.Cryptography.MD5CryptoServiceProvider md5
                = new System.Security.Cryptography.MD5CryptoServiceProvider();
            byte[] retVal = md5.ComputeHash(stream);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < retVal.Length; i++)
            {
                sb.Append(retVal[i].ToString("x2"));
            }
            return sb.ToString();
        }
    }
}
