﻿using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using SanCeng.BLL;
using SanCeng.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SanCeng.Winform2
{
    public partial class FormUserList : Form
    {
        private UserBLL userBll = new UserBLL();
        public FormUserList()
        {
            InitializeComponent();
            dataGridView1.DataSource = userBll.GetAll();
        }

        private void button4_Click(object sender, EventArgs e)
        {           
            dataGridView1.DataSource = userBll.GetAll();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(dataGridView1.SelectedRows.Count<=0)
            {
                MessageBox.Show("没有选中");
                return;
            }
            else
            {
                if(MessageBox.Show("确认删除？","询问",MessageBoxButtons.YesNo)!= 
                    System.Windows.Forms.DialogResult.Yes)
                {
                    return;
                }
                User user = (User)dataGridView1.SelectedRows[0].DataBoundItem;
                userBll.Delete(user.Id);
                dataGridView1.DataSource = userBll.GetAll();
            }
        }

        private void btnAddNew_Click(object sender, EventArgs e)
        {
            FormUserAdd f = new FormUserAdd();
            f.ShowDialog();
            dataGridView1.DataSource = userBll.GetAll();//刷新一下
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //SaveFileDialog
            //OpenFileDialog
            //导出
            string file = "d:/user.xlsx";
            UserBLL userBll = new UserBLL();
            IEnumerable<User> users = userBll.GetAll();
            IWorkbook wb = new XSSFWorkbook();
            ISheet sheet = wb.CreateSheet();
            /*
            for(int i=0;i<users.Count();i++)
            {

            }*/
            int i = 0;
            foreach(User user in users)
            {
                IRow row = sheet.CreateRow(i);
                ICell cell0 = row.CreateCell(0);
                ICell cell1 = row.CreateCell(1);
                ICell cell2 = row.CreateCell(2);

                /*
                int age;
                if(user.Age==null)
                {
                    age = 0;
                }
                else
                {
                   // age = (int)user.Age;
                    age = user.Age.Value;
                }
                cell0.SetCellValue(age);*/
               // cell0.SetCellValue(user.Age==null?0:user.Age.Value);
               cell0.SetCellValue(user.Age??0);
               cell1.SetCellValue(user.UserName);
               cell2.SetCellValue(user.PhoneNum);
                i++;
            }
            using(Stream stream = File.OpenWrite(file))
            {
                wb.Write(stream);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string file = @"d:\daoru.xlsx";
            IWorkbook wb = WorkbookFactory.Create(file);
            ISheet sheet =  wb.GetSheetAt(0);
            int counter = 0;
            for(int i=0;i<=sheet.LastRowNum;i++)
            {
                IRow row = sheet.GetRow(i);
                ICell cell0 = row.GetCell(0);
                ICell cell1 = row.GetCell(1);
                ICell cell2 = row.GetCell(2);
                int age = (int)cell0.NumericCellValue;
                string username = cell1.StringCellValue;
                string phoneNum = cell2.ToString();
                if (userBll.GetByUserName(username) == null)
                {
                    bool ex;
                    userBll.Add2(username, "123456", phoneNum, age, out ex);
                    if(!ex)
                    {
                        counter++;
                    }
                }
            }
            MessageBox.Show("导入成功"+counter);
        }
    }
}
