﻿using SanCeng.DAL;
using SanCeng.Model;
using SanCeng.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanCeng.BLL
{
    public class UserBLL
    {
        private const string Salt = "a%*b!";//md5计算的盐
        private UserDAL uDAL = new UserDAL();

        public long Add2(string userName, string password, string phoneNum, int? age,out bool isExist)
        {
            if (GetByUserName(userName)!=null)
            {
                isExist = true;
                return 0;
            }
            else
            {
                //散列Hash
                string pwdHash = CommonHelper.MD5(password + Salt);//计算“密码+盐”md5值

                isExist = false;
                long id = uDAL.Add(userName, pwdHash, phoneNum, age);
                new LogBLL().Add(id, "新增用户" + userName);//
                return id;
            }            
        }

        public long Add(string userName, string password, string phoneNum, int? age)
        {
            return uDAL.Add(userName, password, phoneNum, age);
        }

        public void Delete(long id)
        {
            uDAL.Delete(id);
        }

        public void Update(User user)
        {
            uDAL.Update(user);
        }

        public User GetById(long id)
        {
            return uDAL.GetById(id);
        }

        public IEnumerable<User> GetAll()
        {
            return uDAL.GetAll();
        }

        public User GetByUserName(string userName)
        {
            return uDAL.GetByUserName(userName);
        }

        public LoginResult Login(string userName,string password)
        {
            /*
            User u = this.GetByUserName(userName);
            if(u==null)
            {
                return LoginResult.UserNameNotFound;
            }
            else if(u.Password!=password)
            {
                return LoginResult.PasswordError;
            }
            else
            {
                new LogBLL().Add(u.Id, u.UserName + "登录了系统");
                return LoginResult.OK;
            }*/
            User u = this.GetByUserName(userName);
            if (u == null)
            {
                return LoginResult.UserNameNotFound;
            }
            else
            {
                //计算用户输入密码+Salt的MD5值
                string userHash = CommonHelper.MD5(password + Salt);
                //if(userHash==u.Password)
                //比较数据库中的Password(其实是保存的密码+盐的MD5值)是否和userHash一致
                if(userHash.Equals(u.Password,StringComparison.OrdinalIgnoreCase))
                {
                    return LoginResult.OK;
                }
                else
                {
                    return LoginResult.PasswordError;
                }
            }
        }
    }
}
